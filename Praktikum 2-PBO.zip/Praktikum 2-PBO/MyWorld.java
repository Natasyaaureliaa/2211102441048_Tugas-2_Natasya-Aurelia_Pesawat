import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.Random;
import java.util.List;

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    int score = 0;

    
    public void setScore(int score){
        this.score = score;
    }
    
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1200, 800, 1); 
        spawnPlayer();
        

    }
    
    private void spawnPlayer(){
        Random rnd = new Random();
        Player p1 = new Player();
        p1.setRotation(270);
        this.addObject(p1, rnd.nextInt(this.getWidth() - 30), this.getHeight()-30);
    }
    
    private void spawnEnemies(){
        Random rnd = new Random();
        for(int i=0; 1<rnd.nextInt(5); i++){
            Enemies en = new Enemies();
            this.addObject(en, rnd.nextInt(this.getWidth() - 30), 5);
        }
    }
    
    public void act(){
        List<Enemies> enemies = this.getObjects(Enemies.class);
        System.out.println(enemies.size());
        if(enemies.size()==0){
            spawnEnemies();
        }
    }
}
